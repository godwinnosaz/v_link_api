<?php

interface HasPublicKey
{
    public function getPublicKey(): PublicKey;
}
