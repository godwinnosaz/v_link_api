<?php

namespace Attestto\SolanaPhpSdk\Exceptions;

use Exception;
class TokenAccountNotFoundError extends Exception
{

}