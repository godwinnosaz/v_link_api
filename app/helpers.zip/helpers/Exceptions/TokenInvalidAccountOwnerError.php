<?php

namespace Attestto\SolanaPhpSdk\Exceptions;

use Exception;
class TokenInvalidAccountOwnerError extends Exception
{

}