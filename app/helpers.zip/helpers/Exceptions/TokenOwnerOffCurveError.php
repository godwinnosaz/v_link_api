<?php

namespace Attestto\SolanaPhpSdk\Exceptions;

use Exception;
class TokenOwnerOffCurveError extends Exception
{

}