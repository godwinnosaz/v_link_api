<?php

namespace Attestto\SolanaPhpSdk\Exceptions;

use Exception;

class InvalidIdResponseException extends Exception
{

}
