<?php

namespace Attestto\SolanaPhpSdk\Borsh;

use Attestto\SolanaPhpSdk\Exceptions\BaseSolanaPhpSdkException;

class BorshException extends BaseSolanaPhpSdkException
{

}
